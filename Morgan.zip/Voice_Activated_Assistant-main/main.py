import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import wikipedia
# import pyjokes
import secrets
import random
import numpy as np

# Voices = engine.getProperty('voices')
# engine.setProperty('voice', Voices[1].id)


listener = sr.Recognizer()
engine = pyttsx3.init()
engine.say('Hello i am Morgan, How can i assist you today')
engine.runAndWait()

def talk(text):
    engine.say(text)
    engine.runAndWait()


def taking_command():
    try:
        with sr.Microphone() as source:
            print("listening...")
            # listen to the microphone as a source
            voice = listener.listen(source)
            # uses google API to listen
            command = listener.recognize_google(voice)
            command = command.lower()
            if 'morgan' in command:
                # removes the need to say morgan
                command = command.replace('morgan', '')
                print(command)

    except:
        pass
    return command

def run():
    command = taking_command()
    print(command)
    if 'play' in command:
        song = command.replace('play', '')
        song = command.replace('morgan', '')
        talk('playing ' + song)
        pywhatkit.playonyt(song, use_api=True)

    elif 'time' in command:
        time = datetime.datetime.now().strftime('%I:%M %p')
        talk('Current time is ' + time)

    elif 'tell me about' in command:
        person = command.replace('tell me about', '')
        info = wikipedia.summary(person, 1)
        print(info)
        talk(info)

    # elif 'joke' in command:
    #    talk(pyjokes.get_joke())


    elif 'how many orders do ' in command:
        PO = ['847 orders today']
        talk(secrets.choice(PO))

    elif 'warehouse' in command:
        PO = ['The warehouse is operational']
        talk(secrets.choice(PO))

    elif 'routes' in command:
        PO = ['Routes is operational']
        talk(secrets.choice(PO))

    elif 'loading' in command:
        PO = ['The production line is operational']
        talk(secrets.choice(PO))
        
    elif 'dave' in command:
        PO = ['All routes have been planned', 'Dave is currently planning the most efficient routes', 'Dave says, the Vans are breaking down...  Just joking', 
        'Dave is currently looking after the drivers. He said he will get back to you soon', 'Dave said he is learning from the data stream']
        talk(secrets.choice(PO))
        
    elif 'ben' in command:
        PO = ['Cookie and Cream flavour ?', 'Ben is currently stocking the warehouse', 'Ben is busy','Ben is looking at how to imporve the warehouse']
        talk(secrets.choice(PO))
        
    elif 'jerry' in command:
        PO = ['Jerry is currently doing cancellations', 'Jerry says all vans are ready to be dispacted', 'Jerry is currently stocking the vans',
        'Jerry is looking at more real time data to plan better routes']
        talk(secrets.choice(PO))

    else:
        talk('Please say that again.')

    while True:
        run()

run()